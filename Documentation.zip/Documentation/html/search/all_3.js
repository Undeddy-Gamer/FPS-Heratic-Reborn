var searchData=
[
  ['damage_25',['damage',['../class_ball_projectile.html#abef79ac6fe49e4fca6c5e568732dda3f',1,'BallProjectile.damage()'],['../class_ball_projectile___m_p.html#a30e1f086d71c056c8c53a53ebc0119d4',1,'BallProjectile_MP.damage()'],['../class_staff.html#af0110bff2eb932a832fd94bf42d9cc92',1,'Staff.damage()'],['../class_staff___m_p.html#aa2bd862bd4862148683958473ecfe87b',1,'Staff_MP.damage()']]],
  ['damagepercentage_26',['damagePercentage',['../class_so_quirk.html#a5bf69cd588ba9b7cab8ab798b6efb1bd',1,'SoQuirk']]],
  ['damageplayer_27',['DamagePlayer',['../class_player_handler.html#a8def0caba4aa661f99eb6ff4e25bba0e',1,'PlayerHandler.DamagePlayer()'],['../class_player_handler___v2.html#af043e5b6fde5fd87e11656eb0869038f',1,'PlayerHandler_V2.DamagePlayer()']]],
  ['description_28',['description',['../class_so_quirk.html#ad118babf1cc9b959e29588b169aae657',1,'SoQuirk']]],
  ['descriptiontext_29',['descriptionText',['../class_quirk_select_panel.html#a909c3d899b083abcdfe5335e836c4f31',1,'QuirkSelectPanel.descriptionText()'],['../class_weapon_select_panel.html#a98a74790a996507804dce0546771aee9',1,'WeaponSelectPanel.descriptionText()']]],
  ['destroyafter_30',['destroyAfter',['../class_ball_projectile___m_p.html#aca59937ad48bc621ba4f6a9a68ee1aa9',1,'BallProjectile_MP']]],
  ['displayname_31',['DisplayName',['../class_network_lobby_player.html#a7867202ee976505d2e6b017c08ac5f93',1,'NetworkLobbyPlayer.DisplayName()'],['../class_selection_screen.html#af5f944de7e18d804a1826f82a64e66b9',1,'SelectionScreen.DisplayName()'],['../class_network_game_player.html#ace3422b329f6f01d58ff431ae2611d62',1,'NetworkGamePlayer.displayName()']]],
  ['dropweapon_32',['DropWeapon',['../class_player.html#a0bf3b6faabf83cb2946b4f9b31fd033a',1,'Player.DropWeapon()'],['../class_player_handler___v2.html#a0111972faa52a82943e379683ac0df66',1,'PlayerHandler_V2.DropWeapon()'],['../class_weapon.html#af635df9c0a33d640a12536bd508e721d',1,'Weapon.DropWeapon()']]]
];
