var searchData=
[
  ['jumpheightpercentage_474',['jumpHeightPercentage',['../class_so_quirk.html#af3964ce71f4cdfa04030d48b7035b845',1,'SoQuirk']]]
];
