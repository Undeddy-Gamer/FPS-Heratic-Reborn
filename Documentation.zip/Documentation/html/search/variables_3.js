var searchData=
[
  ['damage_448',['damage',['../class_ball_projectile.html#abef79ac6fe49e4fca6c5e568732dda3f',1,'BallProjectile.damage()'],['../class_ball_projectile___m_p.html#a30e1f086d71c056c8c53a53ebc0119d4',1,'BallProjectile_MP.damage()'],['../class_staff.html#af0110bff2eb932a832fd94bf42d9cc92',1,'Staff.damage()'],['../class_staff___m_p.html#aa2bd862bd4862148683958473ecfe87b',1,'Staff_MP.damage()']]],
  ['damagepercentage_449',['damagePercentage',['../class_so_quirk.html#a5bf69cd588ba9b7cab8ab798b6efb1bd',1,'SoQuirk']]],
  ['description_450',['description',['../class_so_quirk.html#ad118babf1cc9b959e29588b169aae657',1,'SoQuirk']]],
  ['descriptiontext_451',['descriptionText',['../class_quirk_select_panel.html#a909c3d899b083abcdfe5335e836c4f31',1,'QuirkSelectPanel.descriptionText()'],['../class_weapon_select_panel.html#a98a74790a996507804dce0546771aee9',1,'WeaponSelectPanel.descriptionText()']]],
  ['destroyafter_452',['destroyAfter',['../class_ball_projectile___m_p.html#aca59937ad48bc621ba4f6a9a68ee1aa9',1,'BallProjectile_MP']]],
  ['displayname_453',['DisplayName',['../class_network_lobby_player.html#a7867202ee976505d2e6b017c08ac5f93',1,'NetworkLobbyPlayer.DisplayName()'],['../class_network_game_player.html#ace3422b329f6f01d58ff431ae2611d62',1,'NetworkGamePlayer.displayName()']]]
];
