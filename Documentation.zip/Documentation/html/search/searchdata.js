var indexSectionsWithContent =
{
  0: "abcdefghijlmnopqrstuw",
  1: "bcefgijlmnpqstw",
  2: "bcefgijlmnpqstw",
  3: "acdghijlmnopqrstu",
  4: "abcdefghijlmnopqrstuw",
  5: "r",
  6: "m",
  7: "dgirst",
  8: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties",
  8: "Events"
};

