var searchData=
[
  ['range_502',['range',['../class_staff.html#adedc8c7de8fad85f4791343c3c7d87de',1,'Staff.range()'],['../class_staff___m_p.html#abbee656c39731cc7f05ccc118bb23fc4',1,'Staff_MP.range()']]],
  ['rateoffire_503',['rateOfFire',['../class_staff.html#a53526c1ef8e6c715b1baeebc47b96e24',1,'Staff.rateOfFire()'],['../class_staff___m_p.html#afee08023735eff04631f05cc6d41b2f4',1,'Staff_MP.rateOfFire()']]],
  ['rateoffirepercentage_504',['rateOfFirePercentage',['../class_so_quirk.html#aac4cda2d8e1ad1ff6a34cf6573a1cc92',1,'SoQuirk']]],
  ['reloadspeedpercentage_505',['reloadSpeedPercentage',['../class_so_quirk.html#ae54bfa1d9f5eb4a10960fe60d1378ce7',1,'SoQuirk']]],
  ['resolutiondropdown_506',['resolutionDropdown',['../class_settings_menu.html#ab0df79c7d9415bcb605cd6236f1be238',1,'SettingsMenu']]],
  ['runspeedpercentage_507',['runSpeedPercentage',['../class_so_quirk.html#a512e901e86fdfede7c02c305454f5dfd',1,'SoQuirk']]]
];
