var searchData=
[
  ['capturezone_277',['CaptureZone',['../class_capture_zone.html',1,'']]]
];
