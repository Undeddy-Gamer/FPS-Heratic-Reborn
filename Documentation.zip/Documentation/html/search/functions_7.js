var searchData=
[
  ['load_380',['Load',['../class_player_prefs_save.html#a3d98115caba964dcefe3b805e93726a4',1,'PlayerPrefsSave']]],
  ['loadmainmenu_381',['LoadMainMenu',['../class_game_manager.html#acc5bf2b58e880874333d37213a346d6a',1,'GameManager']]],
  ['loadscene_382',['LoadScene',['../class_game_manager.html#a9e02865d8f82e5c1c3999164d55c517f',1,'GameManager.LoadScene(int sceneIndex)'],['../class_game_manager.html#a054e3128635fa0db23ddb14ccac8d6b1',1,'GameManager.LoadScene(string sceneName)']]]
];
