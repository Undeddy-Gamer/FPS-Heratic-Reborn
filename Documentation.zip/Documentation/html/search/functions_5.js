var searchData=
[
  ['isholdingflag_378',['isHoldingFlag',['../class_player.html#aa7c154866cebd2b2b88e31e5fc089104',1,'Player.isHoldingFlag()'],['../class_player_handler___v2.html#af55d1f7b55ef292b67d008326d28e52b',1,'PlayerHandler_V2.isHoldingFlag()']]]
];
