var searchData=
[
  ['nametext_487',['nameText',['../class_quirk_select_panel.html#a8e911d3f6a7aa88de83889a69eb49f36',1,'QuirkSelectPanel.nameText()'],['../class_weapon_select_panel.html#aaeb525cbb4a6e6bf991522df2eabf817',1,'WeaponSelectPanel.nameText()']]]
];
