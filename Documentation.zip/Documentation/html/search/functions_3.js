var searchData=
[
  ['getweaponteamid_371',['GetWeaponTeamID',['../class_player.html#a0611fe09c9c5e566b3e44e700088e1c2',1,'Player.GetWeaponTeamID()'],['../class_player_handler___v2.html#a79de18d9e6d25553a9eb1a1542a8ceee',1,'PlayerHandler_V2.GetWeaponTeamID()']]]
];
