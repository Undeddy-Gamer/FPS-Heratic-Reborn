var searchData=
[
  ['teamid_551',['teamID',['../class_player.html#a2ca0d5eedf3b254513a041d50c13873c',1,'Player.teamID()'],['../class_player_handler___v2.html#a32172f8a7f0db8e8305fbee153ef158d',1,'PlayerHandler_V2.teamID()']]]
];
