var searchData=
[
  ['joinlobby_80',['JoinLobby',['../class_join_lobby_menu.html#ae8fd5c76e8f5bfe85463d5493e12aefe',1,'JoinLobbyMenu']]],
  ['joinlobbymenu_81',['JoinLobbyMenu',['../class_join_lobby_menu.html',1,'']]],
  ['joinlobbymenu_2ecs_82',['JoinLobbyMenu.cs',['../_join_lobby_menu_8cs.html',1,'']]],
  ['jumpheightpercentage_83',['jumpHeightPercentage',['../class_so_quirk.html#af3964ce71f4cdfa04030d48b7035b845',1,'SoQuirk']]]
];
