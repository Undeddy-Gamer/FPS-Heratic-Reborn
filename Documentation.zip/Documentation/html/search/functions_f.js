var searchData=
[
  ['takedamage_433',['TakeDamage',['../class_enemy.html#acfbe2dc553ea56ed704af9e6dad747df',1,'Enemy.TakeDamage()'],['../class_target.html#a643d8db773527731b4f9ea525b1655ad',1,'Target.TakeDamage()'],['../class_player_shooting_controller.html#a5374769621c1ad60a36bad1aecb761fd',1,'PlayerShootingController.TakeDamage()']]],
  ['togglemenu_434',['ToggleMenu',['../class_main_menu.html#ac7d6bd705e9b1104599f54af569b2bee',1,'MainMenu.ToggleMenu()'],['../class_pause_menu.html#a5ff4839bf1e86f6a19a44b817f09d936',1,'PauseMenu.ToggleMenu()']]]
];
