var searchData=
[
  ['displayname_544',['DisplayName',['../class_selection_screen.html#af5f944de7e18d804a1826f82a64e66b9',1,'SelectionScreen']]]
];
