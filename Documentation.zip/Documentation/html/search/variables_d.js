var searchData=
[
  ['originallocation_488',['originalLocation',['../class_flag.html#a95a2e6a6ec14f64b522525f91f1412dc',1,'Flag.originalLocation()'],['../class_weapon.html#a897bd838a85be2c381c3e3b2032fe87f',1,'Weapon.originalLocation()']]]
];
