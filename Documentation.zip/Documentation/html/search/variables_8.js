var searchData=
[
  ['icon_464',['Icon',['../class_so_quirk.html#a5ecfc04718840354f97ce330d46ce33a',1,'SoQuirk']]],
  ['iconimage_465',['iconImage',['../class_quirk_select_panel.html#abeb39476bbeded9e0dfb50eee73b0e51',1,'QuirkSelectPanel.iconImage()'],['../class_weapon_select_panel.html#ad18dc003f850c8fa524ff4320cfb5d7a',1,'WeaponSelectPanel.iconImage()']]],
  ['impactdecal_466',['impactDecal',['../class_ball_projectile.html#a4040ff0ff522f2bfcc61bc537be81546',1,'BallProjectile.impactDecal()'],['../class_ball_projectile___m_p.html#a89210e59fa01efc1096a2ba28316c4a3',1,'BallProjectile_MP.impactDecal()']]],
  ['impactfx_467',['impactFX',['../class_ball_projectile.html#aaf2a3ae8fb186daf9579c7915190a618',1,'BallProjectile.impactFX()'],['../class_ball_projectile___m_p.html#a5ec2819e98fd7dded440b28e8a20c93b',1,'BallProjectile_MP.impactFX()'],['../class_staff.html#ae8ed6486a0d32f1874a08c152b67546f',1,'Staff.impactFX()'],['../class_staff___m_p.html#a4eb3e233b8d4b83cebe565a696d76e68',1,'Staff_MP.impactFX()']]],
  ['ingamemenuopen_468',['inGameMenuOpen',['../class_game_manager.html#a40d7e1d84ad8734a30836d1730306b2c',1,'GameManager']]],
  ['instance_469',['Instance',['../class_game_manager.html#ad3e717f4fb0f378b969f4457de81f23e',1,'GameManager']]],
  ['isdead_470',['isDead',['../class_player_handler.html#aaa3fe4a9926c249c278971500f93bed6',1,'PlayerHandler.isDead()'],['../class_player_handler___v2.html#aafaa32550b8eeb0a5b0fe919d3ac6c12',1,'PlayerHandler_V2.isDead()']]],
  ['isready_471',['IsReady',['../class_network_lobby_player.html#ae85c70663499fab02d8bee600f9e74ac',1,'NetworkLobbyPlayer']]],
  ['isweapondropable_472',['isWeaponDropable',['../class_weapon.html#a71bdff2135f794e5412646cb82d55615',1,'Weapon']]],
  ['isweaponlocked_473',['isWeaponLocked',['../class_weapon.html#ad1a206306cdc406ea89d1eb924cb4a66',1,'Weapon']]]
];
